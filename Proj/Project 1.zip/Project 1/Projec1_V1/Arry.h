/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arry.h
 * Author: Triet
 *
 * Created on October 29, 2022, 12:46 AM
 */

#ifndef ARRY_H
#define ARRY_H

struct Arry{
    int size;
    float *data;
};

#endif /* ARRY_H */

