/* 
 * Author: Triet Huynh
 * Date: 10/21/2022 8:00PM
 * Purpose: CSC 17A Midterm Problem 5
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"The largest n for n! that can be calculated with char: 5"<<endl
            <<"The largest n for n! that can be calculated with unsigned char: 5"<<endl
            <<"The largest n for n! that can be calculated with short: 7"<<endl
            <<"The largest n for n! that can be calculated with unsigned short: 8"<<endl
            <<"The largest n for n! that can be calculated with int: 13"<<endl
            <<"The largest n for n! that can be calculated with unsigned int: 13"<<endl
            <<"The largest n for n! that can be calculated with long: 13"<<endl
            <<"The largest n for n! that can be calculated with unsigned long: 13"<<endl
            <<"The largest n for n! that can be calculated with long long: 20"<<endl
            <<"The largest n for n! that can be calculated with unsigned long long: 20"<<endl
            <<"The largest n for n! that can be calculated with float: 34"<<endl
            <<"The largest n for n! that can be calculated with double: 170"<<endl
            <<"The largest n for n! that can be calculated with long double: 1754"<<endl;
    //Exit
    return 0;
}