/* 
 * Author: Triet Huynh
 * Date:10/22/2022 6:00PM
 * Purpose:CSC 17A Midterm problem 7 - NASA floats
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"a)"<<endl;
    cout<<"49.1875 base 10 is 31.3 base 16, 61.14 base 8, 110001.0011 base 2, and 62600006 hex NASA float."<<endl
            <<"3.07421875 base 10 is 3.13 base 16, 3.046 base 8, 11.00010011 base 2, and 62600002 hex NASA float."<<endl
            <<"0.2 base 10 is 0.3333... base 16, 0.14631463... base 8, 0.00110011... base 2, and 666666FE hex NASA float."<<endl;
    cout<<"b)"<<endl;
    cout<<"-49.1875 base 10 is 9DA00006 in hex NASA float."<<endl
            <<"-3.07421875 base 10 is 9DA00002 in hex NASA float."<<endl
            <<"-0.2 base 10 is 99999AFE in hex NASA float."<<endl;
    cout<<"c)"<<endl;
    cout<<"69999902 in hex NASA float is 3.3 in decimal"<<endl
            <<"69999903 in hex NASA float is 6.6 in decimal"<<endl
            <<"966667FF in hex NASA float is -1.65 in decimal"<<endl;
    //Exit
    return 0;
}