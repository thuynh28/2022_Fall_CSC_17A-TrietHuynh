/* 
 * File:   main.cpp
 * Author: Triet Huynh
 * Created on Aug 26, 2022, 10:50 PM
 * Purpose: Hello World Program
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout<<"Hello World"<<endl;
    //Exit stage right or left!
    return 0;
}

